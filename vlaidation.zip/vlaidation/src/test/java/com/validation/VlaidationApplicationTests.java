package com.validation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VlaidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
