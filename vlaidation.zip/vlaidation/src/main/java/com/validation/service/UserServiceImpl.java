//package com.validation.service;
//
//import com.validation.entity.UserEntity;
//import com.validation.repository.UserRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class UserServiceImpl {
//
//    private final UserRepository userRepository;
//
//    @Autowired
//    public UserServiceImpl(UserRepository userRepository) {
//        this.userRepository = userRepository;
//    }
//    public List<UserEntity> getAllUsers() {
//
//        return userRepository.findAll();
//    }
//
//    public void addUser(UserEntity user) {
//
//        userRepository.save(user);
//    }
//}
